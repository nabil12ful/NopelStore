<?php
// Database Connect
include("connect.php");
// Paths
    $funcs   = "includes/funcs/";
    $langs   = "includes/langs/";
    $libs    = "includes/libs/";
    $temps   = "includes/temps/";
    $css     = "layout/main/css/";
    $js      = "layout/main/js/";
    $imgs    = "layout/main/images/";
    $uploads = "data/uploads/";

    // includes
    include($funcs . "func.php");
    include($temps . "head.php");
    include($temps . "header.php");
