<?php
include("connect.php");
include("includes/funcs/func.php");
